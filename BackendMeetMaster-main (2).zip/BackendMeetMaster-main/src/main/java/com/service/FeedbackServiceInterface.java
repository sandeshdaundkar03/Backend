package com.service;

import com.model.Feedback;

public interface FeedbackServiceInterface {

	
	public Feedback saveFeedback(Feedback feedback);
}
