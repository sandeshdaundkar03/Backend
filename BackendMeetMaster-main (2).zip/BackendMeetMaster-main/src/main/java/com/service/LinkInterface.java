package com.service;

import com.model.Link;

public interface LinkInterface {

	public Link saveLink(Link link);
	
	
}
