package com.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class MeetingJoining {

	
	@Id
	int id;
}
