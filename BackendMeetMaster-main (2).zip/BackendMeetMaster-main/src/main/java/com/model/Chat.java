package com.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Chat {
	
	@Id
	int id;
	
}
